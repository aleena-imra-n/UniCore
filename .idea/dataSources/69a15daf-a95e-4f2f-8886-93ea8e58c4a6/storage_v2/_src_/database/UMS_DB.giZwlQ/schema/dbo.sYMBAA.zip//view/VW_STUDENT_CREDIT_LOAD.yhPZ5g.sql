
-- V4: Student credit load per semester (from UMS_DB)
CREATE VIEW VW_STUDENT_CREDIT_LOAD AS
SELECT
    e.student_id,
    co.semester_id,
    COUNT(DISTINCT e.enrollment_id)    AS enrolled_courses,
    SUM(c.credit_hours)                AS total_credits,
    s.sub_dept_id
FROM ENROLLMENTS        e
JOIN COURSE_OFFERINGS   co ON co.offering_id = e.offering_id
JOIN COURSES             c ON c.course_id    = co.course_id
JOIN STUDENTS            s ON s.student_id   = e.student_id
WHERE e.status = 'active'
GROUP BY e.student_id, co.semester_id, s.sub_dept_id;
go

