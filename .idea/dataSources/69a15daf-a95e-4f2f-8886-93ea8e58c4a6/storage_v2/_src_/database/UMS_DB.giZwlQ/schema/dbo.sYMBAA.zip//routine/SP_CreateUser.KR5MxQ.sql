
-- ================================================================
-- USER MANAGEMENT STORED PROCEDURES (US-3.8a, from UMS_Complete)
-- ================================================================

-- SP7: Create a new student or teacher account
CREATE PROCEDURE SP_CreateUser
    @role          NVARCHAR(20),
    @full_name     NVARCHAR(100),
    @username      NVARCHAR(50),
    @password      NVARCHAR(255),
    @email         NVARCHAR(100),
    @sub_dept_id   INT            = NULL,
    @major_dept_id INT            = NULL,
    @roll_number   NVARCHAR(20)   = NULL,
    @batch_year    SMALLINT       = NULL,
    @emp_code      NVARCHAR(20)   = NULL,
    @designation   NVARCHAR(60)   = NULL
AS BEGIN
    SET NOCOUNT ON;

    IF @role NOT IN ('student', 'teacher')
    BEGIN
        RAISERROR('Role must be ''student'' or ''teacher''.', 16, 1);
        RETURN;
    END

    IF EXISTS (SELECT 1 FROM USERS WHERE username = @username)
    BEGIN
        RAISERROR('Username already exists. Choose a different username.', 16, 1);
        RETURN;
    END

    IF EXISTS (SELECT 1 FROM USERS WHERE email = @email)
    BEGIN
        RAISERROR('Email address is already registered.', 16, 1);
        RETURN;
    END

    IF @role = 'student'
    BEGIN
        IF @roll_number IS NULL OR LTRIM(RTRIM(@roll_number)) = ''
        BEGIN
            RAISERROR('Roll number is required for students.', 16, 1);
            RETURN;
        END
        IF EXISTS (SELECT 1 FROM STUDENTS WHERE roll_number = @roll_number)
        BEGIN
            RAISERROR('Roll number already exists.', 16, 1);
            RETURN;
        END
        IF @sub_dept_id IS NULL
        BEGIN
            RAISERROR('Sub-department is required for students.', 16, 1);
            RETURN;
        END
        IF @batch_year IS NULL
        BEGIN
            RAISERROR('Batch year is required for students.', 16, 1);
            RETURN;
        END
    END

    IF @role = 'teacher'
    BEGIN
        IF @emp_code IS NULL OR LTRIM(RTRIM(@emp_code)) = ''
        BEGIN
            RAISERROR('Employee code is required for teachers.', 16, 1);
            RETURN;
        END
        IF EXISTS (SELECT 1 FROM TEACHERS WHERE employee_code = @emp_code)
        BEGIN
            RAISERROR('Employee code already exists.', 16, 1);
            RETURN;
        END
        IF @sub_dept_id IS NULL
        BEGIN
            RAISERROR('Sub-department is required for teachers.', 16, 1);
            RETURN;
        END
    END

    DECLARE @new_user_id INT;
    INSERT INTO USERS (username, password_hash, role, email)
    VALUES (@username, @password, @role, @email);
    SET @new_user_id = SCOPE_IDENTITY();

    IF @role = 'student'
    BEGIN
        INSERT INTO STUDENTS (user_id, sub_dept_id, full_name, roll_number, batch_year)
        VALUES (@new_user_id, @sub_dept_id, @full_name, @roll_number, @batch_year);
    END
    ELSE IF @role = 'teacher'
    BEGIN
        INSERT INTO TEACHERS (user_id, sub_dept_id, full_name, employee_code, designation)
        VALUES (@new_user_id, @sub_dept_id, @full_name, @emp_code, @designation);
    END

    SELECT @new_user_id AS new_user_id;
END
go

