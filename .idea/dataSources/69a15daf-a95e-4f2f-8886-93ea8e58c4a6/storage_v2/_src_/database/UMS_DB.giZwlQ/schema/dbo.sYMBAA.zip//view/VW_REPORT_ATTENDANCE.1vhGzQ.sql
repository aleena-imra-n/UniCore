
CREATE VIEW VW_REPORT_ATTENDANCE AS
SELECT 
    sem.semester_name,
    md.name AS dept_name,
    c.course_code,
    c.course_name,
    co.section,
    t.full_name AS teacher_name,
    COUNT(DISTINCT a.class_date) AS total_sessions,
    COUNT(DISTINCT e.student_id) AS student_count,
    CAST(100.0 * SUM(CASE WHEN a.status = 'present' THEN 1 ELSE 0 END) / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS avg_attendance_pct,
    (SELECT COUNT(DISTINCT sub.student_id) 
     FROM (
        SELECT e2.student_id,
               CAST(100.0 * SUM(CASE WHEN a2.status = 'present' THEN 1 ELSE 0 END) / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS att_pct
        FROM ATTENDANCE a2
        JOIN ENROLLMENTS e2 ON a2.enrollment_id = e2.enrollment_id
        WHERE e2.offering_id = co.offering_id
        GROUP BY e2.student_id
     ) sub
     WHERE sub.att_pct < 75) AS students_below_75,
    sem.semester_id
FROM ATTENDANCE a
JOIN ENROLLMENTS e ON a.enrollment_id = e.enrollment_id
JOIN COURSE_OFFERINGS co ON e.offering_id = co.offering_id
JOIN COURSES c ON co.course_id = c.course_id
JOIN SEMESTERS sem ON co.semester_id = sem.semester_id
JOIN MAJOR_DEPARTMENTS md ON c.major_dept_id = md.major_dept_id
JOIN TEACHERS t ON co.teacher_id = t.teacher_id
GROUP BY sem.semester_name, md.name, c.course_code, c.course_name,
         co.section, t.full_name, sem.semester_id, co.offering_id;
go

