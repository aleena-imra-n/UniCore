
-- SP4: Generate a full academic transcript for a student (from UMS_Complete)
--      Returns two result sets:
--        RS1 – per-course rows (one per enrolled course with a final grade)
--        RS2 – per-semester GPA summary + overall CGPA
--
--  Grade-point mapping (percentage-based, standard 4.0 scale):
--      >= 90  → A+  4.00
--      >= 85  → A   4.00
--      >= 80  → A-  3.70
--      >= 75  → B+  3.30
--      >= 70  → B   3.00
--      >= 65  → B-  2.70
--      >= 60  → C+  2.30
--      >= 55  → C   2.00
--      >= 50  → C-  1.70
--      >= 45  → D   1.00
--      <  45  → F   0.00
CREATE PROCEDURE SP_GetTranscript
    @student_id INT
AS
BEGIN
    SET NOCOUNT ON;

    -- 0. Validate student exists
    IF NOT EXISTS (SELECT 1 FROM STUDENTS WHERE student_id = @student_id)
    BEGIN
        RAISERROR('Student not found.', 16, 1);
        RETURN;
    END

    -- 1. Build per-course transcript rows
    ;WITH CourseMarks AS (
        SELECT
            e.enrollment_id,
            e.student_id,
            co.semester_id,
            sem.semester_name,
            sem.start_date                          AS sem_start,
            c.course_code,
            c.course_name,
            c.credit_hours,
            co.section,
            t.full_name                             AS teacher_name,
            SUM(m.marks_obtained)                   AS marks_obtained,
            SUM(m.total_marks)                      AS marks_total,
            CAST(
                100.0 * SUM(m.marks_obtained)
                / NULLIF(SUM(m.total_marks), 0)
            AS DECIMAL(5,2))                        AS percentage
        FROM ENROLLMENTS        e
        JOIN COURSE_OFFERINGS   co  ON co.offering_id  = e.offering_id
        JOIN COURSES            c   ON c.course_id     = co.course_id
        JOIN SEMESTERS          sem ON sem.semester_id = co.semester_id
        JOIN TEACHERS           t   ON t.teacher_id    = co.teacher_id
        JOIN MARKS              m   ON m.enrollment_id = e.enrollment_id
        WHERE e.student_id = @student_id
          AND e.status IN ('active', 'completed')
        GROUP BY
            e.enrollment_id, e.student_id,
            co.semester_id, sem.semester_name, sem.start_date,
            c.course_code, c.course_name, c.credit_hours,
            co.section, t.full_name
    ),
    GradedCourses AS (
        SELECT
            enrollment_id, student_id, semester_id, semester_name, sem_start,
            course_code, course_name, credit_hours, section, teacher_name,
            marks_obtained, marks_total, percentage,
            CASE
                WHEN percentage >= 90 THEN 'A+'
                WHEN percentage >= 85 THEN 'A'
                WHEN percentage >= 80 THEN 'A-'
                WHEN percentage >= 75 THEN 'B+'
                WHEN percentage >= 70 THEN 'B'
                WHEN percentage >= 65 THEN 'B-'
                WHEN percentage >= 60 THEN 'C+'
                WHEN percentage >= 55 THEN 'C'
                WHEN percentage >= 50 THEN 'C-'
                WHEN percentage >= 45 THEN 'D'
                ELSE                       'F'
            END AS letter_grade,
            CAST(CASE
                WHEN percentage >= 90 THEN 4.00
                WHEN percentage >= 85 THEN 4.00
                WHEN percentage >= 80 THEN 3.70
                WHEN percentage >= 75 THEN 3.30
                WHEN percentage >= 70 THEN 3.00
                WHEN percentage >= 65 THEN 2.70
                WHEN percentage >= 60 THEN 2.30
                WHEN percentage >= 55 THEN 2.00
                WHEN percentage >= 50 THEN 1.70
                WHEN percentage >= 45 THEN 1.00
                ELSE                       0.00
            END AS DECIMAL(4,2)) AS grade_points
        FROM CourseMarks
    )
    -- RS1: Per-course rows
    SELECT
        semester_id, semester_name, sem_start,
        course_code, course_name, credit_hours, section, teacher_name,
        marks_obtained, marks_total, percentage, letter_grade, grade_points,
        CAST(grade_points * credit_hours AS DECIMAL(6,2)) AS quality_points
    FROM GradedCourses
    ORDER BY sem_start ASC, course_code ASC;

    -- RS2: Per-semester GPA + running CGPA
    ;WITH CourseMarks2 AS (
        SELECT
            co.semester_id,
            sem.semester_name,
            sem.start_date                          AS sem_start,
            c.credit_hours,
            CAST(
                100.0 * SUM(m.marks_obtained)
                / NULLIF(SUM(m.total_marks), 0)
            AS DECIMAL(5,2))                        AS percentage
        FROM ENROLLMENTS        e
        JOIN COURSE_OFFERINGS   co  ON co.offering_id  = e.offering_id
        JOIN COURSES            c   ON c.course_id     = co.course_id
        JOIN SEMESTERS          sem ON sem.semester_id = co.semester_id
        JOIN MARKS              m   ON m.enrollment_id = e.enrollment_id
        WHERE e.student_id = @student_id
          AND e.status IN ('active', 'completed')
        GROUP BY
            e.enrollment_id,
            co.semester_id, sem.semester_name, sem.start_date,
            c.credit_hours
    ),
    GradedCourses2 AS (
        SELECT
            semester_id, semester_name, sem_start, credit_hours,
            CAST(CASE
                WHEN percentage >= 90 THEN 4.00
                WHEN percentage >= 85 THEN 4.00
                WHEN percentage >= 80 THEN 3.70
                WHEN percentage >= 75 THEN 3.30
                WHEN percentage >= 70 THEN 3.00
                WHEN percentage >= 65 THEN 2.70
                WHEN percentage >= 60 THEN 2.30
                WHEN percentage >= 55 THEN 2.00
                WHEN percentage >= 50 THEN 1.70
                WHEN percentage >= 45 THEN 1.00
                ELSE                       0.00
            END AS DECIMAL(4,2)) AS grade_points
        FROM CourseMarks2
    ),
    SemesterGPA AS (
        SELECT
            semester_id, semester_name, sem_start,
            SUM(credit_hours)                        AS sem_credit_hours,
            SUM(grade_points * credit_hours)         AS sem_quality_points,
            CAST(
                SUM(grade_points * credit_hours)
                / NULLIF(SUM(credit_hours), 0)
            AS DECIMAL(4,2))                         AS semester_gpa,
            COUNT(*)                                 AS course_count
        FROM GradedCourses2
        GROUP BY semester_id, semester_name, sem_start
    )
    SELECT
        semester_id, semester_name, sem_start, course_count, sem_credit_hours,
        CAST(sem_quality_points AS DECIMAL(6,2))     AS sem_quality_points,
        semester_gpa,
        CAST(
            SUM(sem_quality_points) OVER (ORDER BY sem_start
                                          ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW)
            / NULLIF(
                SUM(sem_credit_hours) OVER (ORDER BY sem_start
                                            ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW)
              , 0)
        AS DECIMAL(4,2))                             AS cgpa_so_far
    FROM SemesterGPA
    ORDER BY sem_start ASC;
END
go

