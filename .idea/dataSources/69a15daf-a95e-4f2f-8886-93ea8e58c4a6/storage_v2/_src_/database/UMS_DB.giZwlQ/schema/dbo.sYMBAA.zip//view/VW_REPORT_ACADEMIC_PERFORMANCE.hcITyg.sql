
CREATE VIEW VW_REPORT_ACADEMIC_PERFORMANCE AS
SELECT 
    sem.semester_name,
    md.name AS dept_name,
    c.course_code,
    c.course_name,
    co.section,
    COUNT(DISTINCT e.student_id) AS student_count,
    AVG(CAST(100.0 * m.marks_obtained / NULLIF(m.total_marks, 0) AS DECIMAL(5,2))) AS avg_percentage,
    MIN(CAST(100.0 * m.marks_obtained / NULLIF(m.total_marks, 0) AS DECIMAL(5,2))) AS min_percentage,
    MAX(CAST(100.0 * m.marks_obtained / NULLIF(m.total_marks, 0) AS DECIMAL(5,2))) AS max_percentage,
    sem.semester_id
FROM ENROLLMENTS e
JOIN COURSE_OFFERINGS co ON e.offering_id = co.offering_id
JOIN COURSES c ON co.course_id = c.course_id
JOIN SEMESTERS sem ON co.semester_id = sem.semester_id
JOIN MAJOR_DEPARTMENTS md ON c.major_dept_id = md.major_dept_id
JOIN MARKS m ON e.enrollment_id = m.enrollment_id
GROUP BY sem.semester_name, md.name, c.course_code, c.course_name,
         co.section, sem.semester_id;
go

