
-- SP11: Remove one timetable slot by timetable_id
CREATE PROCEDURE SP_DeleteTimetableSlot
    @timetable_id  INT
AS BEGIN
    SET NOCOUNT ON;

    IF NOT EXISTS (SELECT 1 FROM TIMETABLES WHERE timetable_id = @timetable_id)
    BEGIN
        RAISERROR('Timetable slot not found.', 16, 1);
        RETURN;
    END

    DELETE FROM TIMETABLES WHERE timetable_id = @timetable_id;
    PRINT 'Timetable slot deleted.';
END
go

