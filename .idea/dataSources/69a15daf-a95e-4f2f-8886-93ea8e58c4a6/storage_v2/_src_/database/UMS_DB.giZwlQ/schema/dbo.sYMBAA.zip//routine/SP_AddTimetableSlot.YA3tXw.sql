
-- ================================================================
-- TIMETABLE STORED PROCEDURES (US-3.7a / US-3.11a, from UMS_Complete)
-- ================================================================

-- SP10: Insert one weekly timetable slot for a course offering
--       Advisory room-conflict detection (warn but not hard-block)
CREATE PROCEDURE SP_AddTimetableSlot
    @offering_id  INT,
    @day_of_week  NVARCHAR(10),
    @start_time   TIME,
    @end_time     TIME,
    @room_number  NVARCHAR(20)  = NULL,
    @force        BIT           = 0       -- 1 = insert even if room conflict exists
AS BEGIN
    SET NOCOUNT ON;

    IF @day_of_week NOT IN ('Monday','Tuesday','Wednesday','Thursday','Friday')
    BEGIN
        RAISERROR('day_of_week must be a weekday (Monday–Friday).', 16, 1);
        RETURN;
    END

    IF @end_time <= @start_time
    BEGIN
        RAISERROR('end_time must be after start_time.', 16, 1);
        RETURN;
    END

    IF NOT EXISTS (SELECT 1 FROM COURSE_OFFERINGS WHERE offering_id = @offering_id)
    BEGIN
        RAISERROR('Course offering not found.', 16, 1);
        RETURN;
    END

    IF EXISTS (
        SELECT 1 FROM TIMETABLES
        WHERE offering_id = @offering_id
          AND day_of_week = @day_of_week
          AND start_time  = @start_time
    )
    BEGIN
        RAISERROR('This offering already has a slot on that day at that start time.', 16, 1);
        RETURN;
    END

    -- Room conflict check (overlapping time on same day in same room)
    SELECT
        co.offering_id                           AS conflicting_offering,
        c.course_code,
        co.section,
        t.day_of_week,
        CONVERT(VARCHAR(5), t.start_time, 108)   AS start_time,
        CONVERT(VARCHAR(5), t.end_time,   108)   AS end_time,
        t.room_number
    FROM   TIMETABLES       t
    JOIN   COURSE_OFFERINGS co ON co.offering_id = t.offering_id
    JOIN   COURSES           c ON c.course_id    = co.course_id
    WHERE  @room_number IS NOT NULL
      AND  t.room_number  = @room_number
      AND  t.day_of_week  = @day_of_week
      AND  t.offering_id <> @offering_id
      AND  t.start_time   < @end_time
      AND  t.end_time     > @start_time;

    DECLARE @conflict_count INT = @@ROWCOUNT;

    IF @force = 1 OR @conflict_count = 0
    BEGIN
        INSERT INTO TIMETABLES (offering_id, day_of_week, start_time, end_time, room_number)
        VALUES (@offering_id, @day_of_week, @start_time, @end_time, @room_number);

        SELECT 1 AS inserted, SCOPE_IDENTITY() AS new_timetable_id;
    END
    ELSE
    BEGIN
        SELECT 0 AS inserted, NULL AS new_timetable_id;
    END
END
go

