
-- SP6: Admin approves or rejects a withdrawal request (US-3.5c, from UMS_Complete)
CREATE PROCEDURE SP_ReviewWithdrawal
    @request_id     INT,
    @admin_user_id  INT,
    @decision       NVARCHAR(20),   -- 'approved' | 'rejected'
    @admin_comment  NVARCHAR(300)   = NULL
AS BEGIN
    SET NOCOUNT ON;

    IF @decision NOT IN ('approved', 'rejected')
    BEGIN
        RAISERROR('Decision must be ''approved'' or ''rejected''.', 16, 1);
        RETURN;
    END

    DECLARE @enrollment_id INT, @current_status NVARCHAR(20);
    SELECT @enrollment_id  = enrollment_id,
           @current_status = status
    FROM   WITHDRAWAL_REQUESTS
    WHERE  request_id = @request_id;

    IF @enrollment_id IS NULL
    BEGIN
        RAISERROR('Withdrawal request not found.', 16, 1);
        RETURN;
    END

    IF @current_status <> 'pending'
    BEGIN
        RAISERROR('Only pending requests can be reviewed.', 16, 1);
        RETURN;
    END

    UPDATE WITHDRAWAL_REQUESTS
    SET    status        = @decision,
           admin_comment = @admin_comment,
           reviewed_by   = @admin_user_id,
           reviewed_at   = GETDATE()
    WHERE  request_id    = @request_id;

    IF @decision = 'approved'
    BEGIN
        UPDATE ENROLLMENTS
        SET    status = 'withdrawn'
        WHERE  enrollment_id = @enrollment_id;
    END

    PRINT 'Withdrawal request reviewed.';
END
go

