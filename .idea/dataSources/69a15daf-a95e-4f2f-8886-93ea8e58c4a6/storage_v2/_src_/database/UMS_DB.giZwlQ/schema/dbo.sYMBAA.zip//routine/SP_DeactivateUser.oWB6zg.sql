
-- SP9: Soft-delete a user account
CREATE PROCEDURE SP_DeactivateUser
    @user_id                  INT,
    @requesting_admin_user_id INT
AS BEGIN
    SET NOCOUNT ON;

    DECLARE @is_active BIT, @role NVARCHAR(20);
    SELECT @is_active = is_active, @role = role
    FROM   USERS WHERE user_id = @user_id;

    IF @is_active IS NULL
    BEGIN
        RAISERROR('User not found.', 16, 1);
        RETURN;
    END

    IF @user_id = @requesting_admin_user_id
    BEGIN
        RAISERROR('You cannot deactivate your own account.', 16, 1);
        RETURN;
    END

    IF @is_active = 0
    BEGIN
        RAISERROR('User account is already inactive.', 16, 1);
        RETURN;
    END

    UPDATE USERS SET is_active = 0 WHERE user_id = @user_id;

    PRINT 'User deactivated successfully.';
END
go

