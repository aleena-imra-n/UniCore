
-- ================================================================
-- PART 2: VIEWS
-- ================================================================

-- V1: All courses a student can browse (same faculty + eligibility)
CREATE VIEW VW_STUDENT_VISIBLE_COURSES AS
SELECT
    s.student_id,
    s.roll_number,
    c.course_id,
    c.course_code,
    c.course_name,
    c.credit_hours,
    md.name  AS major_dept,
    sd.name  AS eligible_sub_dept
FROM STUDENTS s
JOIN SUB_DEPARTMENTS           sd  ON s.sub_dept_id    = sd.sub_dept_id
JOIN MAJOR_DEPARTMENTS         md  ON sd.major_dept_id = md.major_dept_id
JOIN COURSE_SUB_DEPT_ELIGIBILITY e ON e.sub_dept_id    = s.sub_dept_id
JOIN COURSES                   c   ON c.course_id      = e.course_id
                                  AND c.major_dept_id   = md.major_dept_id
WHERE c.is_active = 1;
go

