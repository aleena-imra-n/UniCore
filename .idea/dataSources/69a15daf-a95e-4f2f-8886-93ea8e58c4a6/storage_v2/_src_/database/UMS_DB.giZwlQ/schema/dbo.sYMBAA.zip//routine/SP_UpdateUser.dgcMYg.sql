
-- SP8: Update editable fields for a student or teacher
CREATE PROCEDURE SP_UpdateUser
    @user_id          INT,
    @full_name        NVARCHAR(100)  = NULL,
    @email            NVARCHAR(100)  = NULL,
    @new_password     NVARCHAR(255)  = NULL,
    @sub_dept_id      INT            = NULL,
    @designation      NVARCHAR(60)   = NULL,   -- teachers only
    @roll_number      NVARCHAR(20)   = NULL,   -- students only
    @batch_year       SMALLINT       = NULL,   -- students only
    @current_semester TINYINT        = NULL    -- students only
AS BEGIN
    SET NOCOUNT ON;

    DECLARE @role NVARCHAR(20), @is_active BIT;
    SELECT @role = role, @is_active = is_active
    FROM   USERS WHERE user_id = @user_id;

    IF @role IS NULL
    BEGIN
        RAISERROR('User not found.', 16, 1);
        RETURN;
    END

    IF @email IS NOT NULL
       AND EXISTS (SELECT 1 FROM USERS WHERE email = @email AND user_id <> @user_id)
    BEGIN
        RAISERROR('Email address is already in use by another account.', 16, 1);
        RETURN;
    END

    IF @roll_number IS NOT NULL AND @role = 'student'
       AND EXISTS (SELECT 1 FROM STUDENTS
                   WHERE roll_number = @roll_number
                     AND user_id <> @user_id)
    BEGIN
        RAISERROR('Roll number is already assigned to another student.', 16, 1);
        RETURN;
    END

    UPDATE USERS
    SET email         = ISNULL(@email,        email),
        password_hash = ISNULL(@new_password, password_hash)
    WHERE user_id = @user_id;

    IF @role = 'student'
    BEGIN
        UPDATE STUDENTS
        SET full_name        = ISNULL(@full_name,        full_name),
            sub_dept_id      = ISNULL(@sub_dept_id,      sub_dept_id),
            roll_number      = ISNULL(@roll_number,      roll_number),
            batch_year       = ISNULL(@batch_year,       batch_year),
            current_semester = ISNULL(@current_semester, current_semester)
        WHERE user_id = @user_id;
    END
    ELSE IF @role = 'teacher'
    BEGIN
        UPDATE TEACHERS
        SET full_name   = ISNULL(@full_name,   full_name),
            sub_dept_id = ISNULL(@sub_dept_id, sub_dept_id),
            designation = ISNULL(@designation, designation)
        WHERE user_id = @user_id;
    END

    PRINT 'User updated successfully.';
END
go

