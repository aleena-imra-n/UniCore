
CREATE VIEW VW_REPORT_ENROLLMENT AS
SELECT 
    s.semester_id,
    s.semester_name,
    d.name AS dept_name,
    c.course_code,
    c.course_name,
    sec.section,
    t.full_name AS teacher_name,

    COUNT(e.student_id) AS total_enrolled,

    SUM(CASE WHEN e.status = 'Active' THEN 1 ELSE 0 END)     AS active_count,
    SUM(CASE WHEN e.status = 'Withdrawn' THEN 1 ELSE 0 END)  AS withdrawn_count,
    SUM(CASE WHEN e.status = 'Completed' THEN 1 ELSE 0 END)  AS completed_count

FROM ENROLLMENTS e
JOIN COURSE_OFFERINGS sec ON sec.offering_id = e.offering_id
JOIN COURSES c            ON c.course_id = sec.course_id
JOIN SEMESTERS s          ON s.semester_id = sec.semester_id
JOIN TEACHERS t           ON t.teacher_id = sec.teacher_id
JOIN SUB_DEPARTMENTS sd   ON sd.sub_dept_id = sec.sub_dept_id
JOIN MAJOR_DEPARTMENTS d  ON d.major_dept_id = sd.major_dept_id

GROUP BY 
    s.semester_id,
    s.semester_name,
    d.name,
    c.course_code,
    c.course_name,
    sec.section,
    t.full_name;
go

