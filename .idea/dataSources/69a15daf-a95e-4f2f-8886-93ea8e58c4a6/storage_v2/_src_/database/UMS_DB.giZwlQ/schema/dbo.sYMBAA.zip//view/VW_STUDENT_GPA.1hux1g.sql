
-- V3: Student marks/percentage summary per course
CREATE VIEW VW_STUDENT_GPA AS
SELECT
    s.student_id,
    s.roll_number,
    s.full_name,
    co.semester_id,
    c.course_name,
    SUM(m.marks_obtained) AS total_obtained,
    SUM(m.total_marks)    AS total_possible,
    CAST(
        100.0 * SUM(m.marks_obtained) / NULLIF(SUM(m.total_marks),0)
    AS DECIMAL(5,2))      AS percentage
FROM STUDENTS       s
JOIN ENROLLMENTS    e   ON e.student_id    = s.student_id
JOIN COURSE_OFFERINGS co ON co.offering_id = e.offering_id
JOIN COURSES        c   ON c.course_id     = co.course_id
JOIN MARKS          m   ON m.enrollment_id = e.enrollment_id
GROUP BY s.student_id, s.roll_number, s.full_name,
         co.semester_id, c.course_name;
go

