
-- SP5: Student submits a course withdrawal request (US-3.5a, from UMS_Complete)
CREATE PROCEDURE SP_RequestWithdrawal
    @enrollment_id  INT,
    @reason         NVARCHAR(500)
AS BEGIN
    SET NOCOUNT ON;

    DECLARE @student_id INT, @status NVARCHAR(20);
    SELECT @student_id = student_id,
           @status     = status
    FROM   ENROLLMENTS
    WHERE  enrollment_id = @enrollment_id;

    IF @student_id IS NULL
    BEGIN
        RAISERROR('Enrollment not found.', 16, 1);
        RETURN;
    END

    IF @status <> 'active'
    BEGIN
        RAISERROR('Only active enrollments can be withdrawn.', 16, 1);
        RETURN;
    END

    IF EXISTS (
        SELECT 1 FROM WITHDRAWAL_REQUESTS
        WHERE enrollment_id = @enrollment_id
          AND status = 'pending'
    )
    BEGIN
        RAISERROR('A pending withdrawal request already exists for this enrollment.', 16, 1);
        RETURN;
    END

    -- Delete old rejected request so student can re-apply
    DELETE FROM WITHDRAWAL_REQUESTS
    WHERE enrollment_id = @enrollment_id
      AND status = 'rejected';

    INSERT INTO WITHDRAWAL_REQUESTS (enrollment_id, student_id, reason)
    VALUES (@enrollment_id, @student_id, @reason);

    PRINT 'Withdrawal request submitted.';
END
go

