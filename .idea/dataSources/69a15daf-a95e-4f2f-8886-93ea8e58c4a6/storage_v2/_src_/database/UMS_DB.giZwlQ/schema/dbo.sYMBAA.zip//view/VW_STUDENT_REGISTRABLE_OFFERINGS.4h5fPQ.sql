
-- V2: Active offerings a student can register into
CREATE VIEW VW_STUDENT_REGISTRABLE_OFFERINGS AS
SELECT
    s.student_id,
    s.roll_number,
    co.offering_id,
    c.course_code,
    c.course_name,
    co.section,
    co.room_number,
    co.schedule_days,
    co.class_time,
    co.max_capacity,
    sem.semester_name,
    t.full_name  AS teacher_name
FROM STUDENTS s
JOIN COURSE_OFFERINGS           co  ON co.sub_dept_id  = s.sub_dept_id
JOIN COURSES                    c   ON c.course_id     = co.course_id
JOIN SEMESTERS                  sem ON sem.semester_id = co.semester_id
JOIN TEACHERS                   t   ON t.teacher_id    = co.teacher_id
JOIN COURSE_SUB_DEPT_ELIGIBILITY e
    ON e.course_id   = co.course_id
   AND e.sub_dept_id = s.sub_dept_id
WHERE sem.is_active = 1;
go

