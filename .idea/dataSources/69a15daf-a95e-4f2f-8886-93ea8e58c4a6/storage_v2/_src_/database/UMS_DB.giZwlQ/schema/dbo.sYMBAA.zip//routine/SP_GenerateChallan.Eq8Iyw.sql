
-- SP3: Generate a fee challan for a student/semester
CREATE PROCEDURE SP_GenerateChallan
    @student_id  INT,
    @semester_id INT
AS BEGIN
    SET NOCOUNT ON;
    DECLARE @fee_id INT;

    SELECT @fee_id = fee_id
    FROM FEE_RECORDS
    WHERE student_id = @student_id AND semester_id = @semester_id;

    IF @fee_id IS NULL
    BEGIN
        RAISERROR('No fee record found for this student/semester.', 16, 1);
        RETURN;
    END

    IF EXISTS (
        SELECT 1 FROM FEE_CHALLANS
        WHERE fee_id = @fee_id AND is_paid = 0
    )
    BEGIN
        RAISERROR('An unpaid challan already exists.', 16, 1);
        RETURN;
    END

    DECLARE @challan_no NVARCHAR(30) =
        N'CH-' + CAST(@student_id  AS NVARCHAR) +
        N'-'   + CAST(@semester_id AS NVARCHAR) +
        N'-'   + FORMAT(GETDATE(),'yyyyMMddHHmm');

    INSERT INTO FEE_CHALLANS (fee_id, challan_number, expiry_date)
    VALUES (@fee_id, @challan_no, DATEADD(DAY, 15, GETDATE()));

    SELECT challan_number, expiry_date
    FROM FEE_CHALLANS
    WHERE fee_id = @fee_id
    ORDER BY generated_date DESC;
END
go

