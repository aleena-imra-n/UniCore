
-- SP2: Bulk mark attendance for a class session (JSON input)
CREATE PROCEDURE SP_MarkAttendance
    @offering_id INT,
    @class_date  DATE,
    @status_list NVARCHAR(MAX)
AS BEGIN
    SET NOCOUNT ON;
    INSERT INTO ATTENDANCE (enrollment_id, class_date, status)
    SELECT enrollment_id, @class_date, status
    FROM OPENJSON(@status_list)
    WITH (enrollment_id INT, status NVARCHAR(10));
END
go

