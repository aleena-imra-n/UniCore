
-- ================================================================
-- PART 3: STORED PROCEDURES
-- ================================================================

-- SP1: Register a student
--      Validates eligibility + prerequisites + capacity + duplicates + credit limit
CREATE   PROCEDURE SP_RegisterStudent
    @student_id  INT,
    @offering_id INT
AS
BEGIN
    SET NOCOUNT ON;

    -- ────────────────────────────────────────────────
    -- 1. ELIGIBILITY CHECK
    -- ────────────────────────────────────────────────
    IF NOT EXISTS (
        SELECT 1
        FROM COURSE_OFFERINGS co
        JOIN COURSE_SUB_DEPT_ELIGIBILITY e
            ON e.course_id = co.course_id
        JOIN STUDENTS s
            ON s.student_id  = @student_id
           AND s.sub_dept_id = co.sub_dept_id
           AND s.sub_dept_id = e.sub_dept_id
        WHERE co.offering_id = @offering_id
    )
    BEGIN
        RAISERROR('Student not eligible for this offering.', 16, 1);
        RETURN;
    END

    -- ────────────────────────────────────────────────
    -- 2. GET COURSE ID
    -- ────────────────────────────────────────────────
    DECLARE @course_id INT;

    SELECT @course_id = course_id
    FROM COURSE_OFFERINGS
    WHERE offering_id = @offering_id;

    -- ────────────────────────────────────────────────
    -- 3. PREREQUISITE CHECK
    -- ────────────────────────────────────────────────
    IF EXISTS (
        SELECT 1
        FROM COURSE_PREREQUISITES cp
        WHERE cp.course_id = @course_id
          AND cp.is_mandatory = 1
          AND NOT EXISTS (
              SELECT 1
              FROM ENROLLMENTS e
              JOIN COURSE_OFFERINGS co2
                    ON co2.offering_id = e.offering_id
              JOIN (
                  SELECT m.enrollment_id,
                         CAST(100.0 * SUM(m.marks_obtained)
                              / NULLIF(SUM(m.total_marks), 0)
                         AS DECIMAL(5,2)) AS pct
                  FROM MARKS m
                  GROUP BY m.enrollment_id
              ) grades
                    ON grades.enrollment_id = e.enrollment_id
              WHERE e.student_id  = @student_id
                AND co2.course_id = cp.prereq_course_id
                AND e.status      = 'completed'
                AND grades.pct   >= cp.min_grade_pct
          )
    )
    BEGIN
        RAISERROR('Prerequisite course not completed with required grade.', 16, 1);
        RETURN;
    END

    -- ────────────────────────────────────────────────
    -- 4. CAPACITY CHECK
    -- ────────────────────────────────────────────────
    DECLARE @enrolled INT, @cap INT;

    SELECT
        @enrolled = COUNT(*),
        @cap      = MAX(co.max_capacity)
    FROM ENROLLMENTS e
    JOIN COURSE_OFFERINGS co
        ON co.offering_id = @offering_id
    WHERE e.offering_id = @offering_id
      AND e.status = 'active';

    IF @enrolled >= @cap
    BEGIN
        RAISERROR('Course offering is at full capacity.', 16, 1);
        RETURN;
    END

    -- ────────────────────────────────────────────────
    -- 5. DUPLICATE ENROLLMENT CHECK
    -- ────────────────────────────────────────────────
    IF EXISTS (
        SELECT 1
        FROM ENROLLMENTS
        WHERE student_id = @student_id
          AND offering_id = @offering_id
    )
    BEGIN
        RAISERROR('Student already enrolled in this offering.', 16, 1);
        RETURN;
    END

    -- ────────────────────────────────────────────────
    -- 6. CREDIT LIMIT CHECK
    -- ────────────────────────────────────────────────
    DECLARE @new_course_credits TINYINT;
    DECLARE @current_credits    TINYINT;
    DECLARE @max_credits        TINYINT;
    DECLARE @overload_credits   TINYINT;
    DECLARE @semester_id        INT;
    DECLARE @sub_dept_id        INT;

    -- Get course credits + semester
    SELECT
        @semester_id        = co.semester_id,
        @new_course_credits = c.credit_hours
    FROM COURSE_OFFERINGS co
    JOIN COURSES c
        ON c.course_id = co.course_id
    WHERE co.offering_id = @offering_id;

    -- Get student sub dept
    SELECT @sub_dept_id = sub_dept_id
    FROM STUDENTS
    WHERE student_id = @student_id;

    -- Get credit policy
    SELECT
        @max_credits      = max_credits,
        @overload_credits = overload_credits
    FROM CREDIT_POLICIES
    WHERE sub_dept_id = @sub_dept_id
      AND is_active = 1;

    -- Current enrolled credits
    SELECT @current_credits = ISNULL(SUM(c2.credit_hours), 0)
    FROM ENROLLMENTS e2
    JOIN COURSE_OFFERINGS co2
        ON co2.offering_id = e2.offering_id
    JOIN COURSES c2
        ON c2.course_id = co2.course_id
    WHERE e2.student_id   = @student_id
      AND co2.semester_id = @semester_id
      AND e2.status       = 'active';

    -- Hard limit: block if exceeds overload credits
    IF (@current_credits + @new_course_credits) > @overload_credits
    BEGIN
        RAISERROR(
            'Credit limit exceeded. Max allowed: %d, Current: %d, Course: %d',
            16, 1,
            @overload_credits,
            @current_credits,
            @new_course_credits
        );
        RETURN;
    END

    -- Soft warning: still enrolls but warns
    IF (@current_credits + @new_course_credits) > @max_credits
    BEGIN
        PRINT 'WARNING: Exceeding standard credit limit (overload). Dean approval may be required.';
    END

    -- ────────────────────────────────────────────────
    -- 7. INSERT ENROLLMENT
    -- ────────────────────────────────────────────────
    INSERT INTO ENROLLMENTS (student_id, offering_id, status)
    VALUES (@student_id, @offering_id, 'active');

    PRINT 'Enrollment successful.';
END
go

